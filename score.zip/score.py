from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
from datetime import datetime
from oauth2client.service_account import ServiceAccountCredentials
import gspread
import uvicorn

def get_google_sheet():
    scope = ['https://spreadsheets.google.com/feeds',
             'https://www.googleapis.com/auth/drive']
        
    credentials_info = {
        "type": "service_account",
        "project_id": "gbsw-hk",
        "private_key_id": "5a64a9e069e930d0bee875e3d37bbb77756a2735",
        "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDO7mephUOuU5wy\nEZmdLSvulj7WklwSaa6oPAHqBJt2aD6w5ibqaIi1zOSNlj9l8CxgAmVOZBi2uWcR\nqpicxnZ+7PeSackRJsNuxaKzsSUvsODW/Ri3IiMPY7TPr+Ij11ipT4QxCt8TfOyb\n97uRjJYrJZ1tZ7vd7xrrcaZdFrkVcUj9oqBC6kXvh3VDdhGWmERBvo279R/yXBfQ\nh3rgKDScbhapmIAOzottv9mj6tVHsDQJESYUfKvs5ckgFbJNX3yqrJe3cdRmJNWS\n6k6/0I0Qn/C4HAelv9KDus4rXH8INc7zBoxDuGPcU6+s34FUs0TSOFaw038G7K7u\nioEEX9/jAgMBAAECggEAHu7oOSD46pozZbqteMpUCxDo/ittLxAe8frdGw4AQrWM\n9ZBvbdLIPku4OMAmjwcATdkzKqzvktUT/BdBRA0DkVq8HDt1uVDO8y6rxpUrEWjY\nBjCvMqUcPO8zNr68nTinrND8WlZyiBfAc6+XREfnT4uKb9yLar7qX8V3+z9r1dv5\n/7x811vQtaqN55hdE5ZsPs4Bih5sygrYfe/9Dq7/0b6bHPO5ElU127dnovlpvEZt\nl/KV530PHstex57azYZIyZ25VlB96z5V81kH2FkkjP0pkRIV0DL1V9e7VzIx92H3\nkOdwtOIzTykfM9L0a/sHq/qF5p+aKsjROij3A3Bt6QKBgQD0YeipEo1XbaPPXMWs\neAfQgaRV/doShRZYfzsqTa81tB0AaMzJx6EWkPbs3kuA9OLyh0ZqffOdBGAvhepE\n27WdrwnRjVbJUiUrz6tNAb/jId9C3KauYNWtLVgx9gk+F3UepXGbTu6oO3Xxo2i9\nJhxEQAeQXhd85Rv6XMeRg0El+QKBgQDYxLjHaZ/xS4+CUwnDNHdhK3Rh0ZvkqduV\n2ETfNjvEQTLV3pLyRwfkh8YxliMLnjcyxKAutuZCitsewJ9BNAS8xp7MjoxthkMu\nJ4c8e8aTn0LiMPw1e/YCF5GlNlfns49rk+vw70beZRJgvO99LoNBoMeP0sjPKZJ6\nir6h6377uwKBgDYtcofw/faw7szs00HuBkV6SDVsJqlOaerKohI50KsGOBu8IBJn\nuFWpY6SVj4WSRLHhvYGkVJqtuqkudgY38yZ3BKU5QVE2bdktm9thlOnEu5s2EZm9\nDAHteIzy74+dYbCemvYEZLJVJEuin3i3dzLGQycFRQ3CORai9PdUct/5AoGBAIY/\nb2Cw3cmGzl4cJ1OpzrVzQCTEuBOpzsDCrATBhcpJxr4FlmRN8WlrXSegoBu15OGg\nPMQxqfFUJdip2vd6y+RN7lMphXbfTAPtnyeqUJVkcPu88rX9C6LIDf+P5GkvH4e0\nmM8ioXViizs2R+vzPn8KoA1Gse77BCi4fM+zFXW5AoGAVjhzG2Thm1T1qdfD38yJ\n2y6wACP2CbZghiUd/4CdhRhRkSo2T3H2g02kf+9Hlc2p6DViCMwy/XxbnvnZgi7G\n7jjQPZB8wfejvdFCMu5/JFpsL+i4Ujftmd7aIghNohwwRGKIsvZRfYJigzE8D8Cw\ngGz1YVSNReyXBVrQ2y0TPuY=\n-----END PRIVATE KEY-----\n",
        "client_email": "score-331@score-440014.iam.gserviceaccount.com",
        "client_id": "114111484896464944961",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/score-331%40score-440014.iam.gserviceaccount.com",
    }

    credential = ServiceAccountCredentials.from_json_keyfile_dict(credentials_info, scope)
    gc = gspread.authorize(credential)
    
    spreadsheet_url = "https://docs.google.com/spreadsheets/d/1AgWHFACkk8-xmcHKJSp-isG7Ygllmhn8L9npzrEvE18/edit?resourcekey=&gid=1504828157"
    doc = gc.open_by_url(spreadsheet_url)
    sheet = doc.worksheet("1")
    
    df = pd.DataFrame(sheet.get_all_values())
    df.rename(columns=df.iloc[0], inplace=True)
    df.drop(df.index[0], inplace=True)
    
    return df

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def calculate_scores(df):
    # 데이터 타입 설정
    df['Team'] = df['Team'].astype(str)
    df['점수'] = df['점수'].astype(int)
    df['타임스탬프'] = df['타임스탬프'].str.replace('오전', 'AM').str.replace('오후', 'PM')
    df['타임스탬프'] = pd.to_datetime(df['타임스탬프'], format='%Y. %m. %d %p %I:%M:%S')

    # 이메일-팀 별로 최대 점수만 남기기
    df = df.sort_values(by=['이메일 주소', 'Team', '점수'], ascending=[True, True, False])
    df = df.drop_duplicates(subset=['이메일 주소', 'Team'], keep='first')

    # 팀별 통계 계산
    team_stats = df.groupby('Team').agg(
        average_score=('점수', 'mean'),
        vote_count=('점수', 'count'),
        first_vote=('타임스탬프', 'min'),
        last_vote=('타임스탬프', 'max')
    ).reset_index()

    # 투표 시간 길이 계산
    team_stats['vote_duration'] = (team_stats['last_vote'] - team_stats['first_vote']).dt.total_seconds()

    # 평균 점수 및 투표 지속 시간 기준으로 정렬 후 순위 계산
    team_stats = team_stats.sort_values(by=['average_score', 'vote_duration'], ascending=[False, True]).reset_index(drop=True)
    team_stats['rank'] = team_stats['average_score'].rank(method='min', ascending=False).astype(int)

    # 총 투표자 수 계산
    total_voters = df['이메일 주소'].nunique()

    # 결과 반환
    result = {
        "team_scores": team_stats[['Team', 'average_score', 'vote_count', 'rank']].to_dict(orient="records"),
        "total_voters": total_voters
    }
    return result

@app.get("/scoreboard")
async def get_scoreboard():
    try:
        df = get_google_sheet()
        result = calculate_scores(df)
        return result
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
